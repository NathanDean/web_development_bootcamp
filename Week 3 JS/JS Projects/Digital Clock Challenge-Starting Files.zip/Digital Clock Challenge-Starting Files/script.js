//Hints
//function setTime() {
   
    
    
   
//}
//setTime();